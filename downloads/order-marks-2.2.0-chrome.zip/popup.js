(function () {
  "use strict";
  const api = globalThis.browser?.runtime?.id ? globalThis.browser : globalThis.chrome;
  const toggle = document.querySelector("#quick-enabled");
  const status = document.querySelector("#quick-status");

  EOHSettings.load().then((settings) => {
    toggle.checked = settings.enabled;
    status.textContent = settings.enabled ? "On" : "Off";
  });

  toggle.addEventListener("change", async () => {
    const settings = await EOHSettings.load();
    await EOHSettings.save({ ...settings, enabled: toggle.checked });
    status.textContent = toggle.checked ? "On" : "Off";
  });

  document.querySelector("#open-settings").addEventListener("click", () => {
    api.runtime.openOptionsPage();
    window.close();
  });
})();
