(function () {
  "use strict";

  const api = globalThis.browser?.runtime?.id ? globalThis.browser : globalThis.chrome;

  api.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message || message.type !== "eoh:open-options") return false;

    try {
      const opening = api.runtime.openOptionsPage();
      if (opening && typeof opening.then === "function") {
        opening.then(
          () => sendResponse({ ok: true }),
          (error) => sendResponse({ ok: false, message: String(error) }),
        );
        return true;
      }
      sendResponse({ ok: true });
    } catch (error) {
      sendResponse({ ok: false, message: String(error) });
    }
    return false;
  });
})();
