(function () {
  "use strict";

  const form = document.querySelector("#settings-form");
  const status = document.querySelector("#save-status");
  const enabledStatus = document.querySelector("#enabled-status");
  let saveTimer;

  function setForm(settings) {
    Object.entries(settings).forEach(([key, value]) => {
      const field = form.elements.namedItem(key) || document.querySelector(`#${key}`);
      if (!field) return;
      if (field instanceof RadioNodeList) {
        field.value = String(value);
      } else if (field.type === "checkbox") {
        field.checked = Boolean(value);
      } else if (field.type === "number") {
        field.value = Number(value).toFixed(2);
      } else {
        field.value = String(value);
      }
    });
    updateReadouts();
  }

  function getForm() {
    const data = new FormData(form);
    const values = {};
    Object.keys(EOHSettings.DEFAULTS).forEach((key) => {
      const field = form.elements.namedItem(key) || document.querySelector(`#${key}`);
      if (!field) return;
      if (field.type === "checkbox") values[key] = field.checked;
      else if (field.type === "number" || field.type === "range") values[key] = Number(field.value);
      else values[key] = data.get(key);
    });
    values.enabled = document.querySelector("#enabled").checked;
    return EOHSettings.normalise(values);
  }

  function updateReadouts() {
    ["priceColour", "deliveryColour", "specialColour", "duplicateColour"].forEach((id) => {
      document.querySelector(`#${id}Value`).textContent = document.querySelector(`#${id}`).value.toUpperCase();
    });
    document.querySelector("#tintStrengthValue").value = document.querySelector("#tintStrength").value;
    enabledStatus.textContent = document.querySelector("#enabled").checked ? "On" : "Off";
    document.querySelector("#select-marked-rules").disabled = !document.querySelector("#showSelectMarked").checked;
    ["selectPrice", "selectDelivery", "selectSpecial", "selectDuplicates"].forEach((id) => {
      document.querySelector(`#${id}`).disabled = document.querySelector("#invertSelection").checked;
    });
    document.body.classList.toggle("is-disabled", !document.querySelector("#enabled").checked);
  }

  async function save() {
    clearTimeout(saveTimer);
    status.textContent = "Saving…";
    await EOHSettings.save(getForm());
    status.textContent = "Saved";
    saveTimer = setTimeout(() => {
      status.textContent = "Changes save as you make them.";
    }, 1800);
  }

  form.addEventListener("input", () => {
    updateReadouts();
    clearTimeout(saveTimer);
    saveTimer = setTimeout(save, 250);
  });

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    await save();
  });

  document.querySelector("#enabled").addEventListener("input", () => {
    updateReadouts();
    clearTimeout(saveTimer);
    saveTimer = setTimeout(save, 100);
  });

  document.querySelector("#reset-button").addEventListener("click", async () => {
    setForm(await EOHSettings.reset());
    document.querySelector("#enabled").checked = EOHSettings.DEFAULTS.enabled;
    updateReadouts();
    status.textContent = "Defaults restored";
  });

  EOHSettings.load().then((settings) => {
    setForm(settings);
    document.querySelector("#enabled").checked = settings.enabled;
    updateReadouts();
  });
})();
