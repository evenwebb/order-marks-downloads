(function () {
  "use strict";

  const api = globalThis.browser?.runtime?.id ? globalThis.browser : globalThis.chrome;
  const CLASS_NAMES = ["eoh-marked", "eoh-price", "eoh-delivery", "eoh-duplicate", "eoh-style-wash", "eoh-style-edge", "eoh-style-outline"];
  const STATUS_LABELS = {
    ALL_ORDERS: "All orders",
    AWAITING_SHIPMENT: "Awaiting dispatch",
    PAID_SHIPPED: "Paid and dispatched",
    AWAITING_PAYMENT: "Awaiting payment",
  };
  let settings = { ...EOHSettings.DEFAULTS };
  let currentUrl = location.href;
  let updateFrame = 0;
  let tableObserver;

  function getStatus() {
    const filter = new URL(location.href).searchParams.get("filter") || "";
    const fromUrl = filter.replace(/^status:/, "");
    if (fromUrl) return fromUrl;
    const selected = document.querySelector('select[name="fl-status"] option:checked');
    return selected ? selected.value : "";
  }

  function pageIsEnabled(status) {
    const key = EOHSettings.PAGE_KEYS[status];
    return Boolean(settings.enabled && key && settings[key]);
  }

  function parseMoney(text) {
    if (!text) return 0;
    const match = String(text).replace(/\u00a0/g, " ").match(/-?\s*(?:£|GBP)?\s*\d[\d.,]*/i);
    if (!match) return 0;
    let value = match[0].replace(/[^\d,.-]/g, "");
    const comma = value.lastIndexOf(",");
    const dot = value.lastIndexOf(".");

    if (comma !== -1 && dot !== -1) {
      if (comma > dot) value = value.replace(/\./g, "").replace(",", ".");
      else value = value.replace(/,/g, "");
    } else if (comma !== -1) {
      const decimals = value.length - comma - 1;
      value = decimals === 2 ? value.replace(",", ".") : value.replace(/,/g, "");
    }

    const number = Number.parseFloat(value);
    return Number.isFinite(number) ? number : 0;
  }

  function findOrdersTable() {
    const tables = [...document.querySelectorAll("table")];
    return tables.find((table) => table.querySelector("caption")?.textContent.trim() === "Orders")
      || document.querySelector("table.table-grid-component.new-grid")
      || tables.find((table) => table.querySelector('input[data-testid="order-checkbox"]'))
      || null;
  }

  function columnIndex(table, id, name) {
    const headers = [...table.querySelectorAll("thead tr:first-child > th")];
    const byId = headers.findIndex((header) => header.id === id);
    if (byId >= 0) return byId;
    return headers.findIndex((header) => header.textContent.trim().toLowerCase().startsWith(name));
  }

  function rowPrice(row, index, selector) {
    const cells = row.querySelectorAll(":scope > td");
    const cell = index >= 0 ? cells[index] : null;
    const source = cell?.querySelector(selector) || cell;
    return parseMoney(source?.textContent || "");
  }

  function buyerKey(row, checkbox) {
    if (checkbox?.dataset.buyerId) return checkbox.dataset.buyerId.trim().toLowerCase();
    const spans = row.querySelectorAll(".buyer-modal-trigger-wrapper button span");
    return spans.length ? spans[spans.length - 1].textContent.trim().toLowerCase() : "";
  }

  function postageElement(cell) {
    if (!cell) return null;
    const item = [...cell.querySelectorAll(".price-column-item")]
      .find((element) => /\bpostage\b/i.test(element.textContent));
    if (item) return item;
    const label = [...cell.querySelectorAll("span")]
      .find((element) => /\bpostage\b/i.test(element.textContent));
    return label?.parentElement || null;
  }

  function spanCount(elements) {
    return elements.reduce((total, element) => {
      const span = Number.parseInt(element.getAttribute("colspan") || "1", 10);
      return total + (Number.isFinite(span) && span > 0 ? span : 1);
    }, 0);
  }

  function restoreTrailingSpan(row) {
    row.querySelectorAll(":scope > td[data-eoh-original-colspan]").forEach((cell) => {
      const original = cell.dataset.eohOriginalColspan;
      if (original) cell.setAttribute("colspan", original);
      else cell.removeAttribute("colspan");
      delete cell.dataset.eohOriginalColspan;
    });
  }

  function fillTrailingColumns(row, columnCount) {
    const cells = [...row.querySelectorAll(":scope > td")];
    const missing = columnCount - spanCount(cells);
    const lastCell = cells[cells.length - 1];
    if (!lastCell || missing <= 0) return;
    lastCell.dataset.eohOriginalColspan = lastCell.getAttribute("colspan") || "";
    lastCell.colSpan = (Number.parseInt(lastCell.getAttribute("colspan") || "1", 10) || 1) + missing;
  }

  function getOrders(table) {
    const totalIndex = columnIndex(table, "totalprice", "total");
    const subtotalIndex = columnIndex(table, "sold_for", "subtotal");
    const columnCount = spanCount([...table.querySelectorAll("thead tr:first-child > th")]);
    const tableRows = [...table.querySelectorAll("tbody > tr")];
    return [...table.querySelectorAll("tbody > tr.order-info")]
      .map((row) => {
        const checkbox = row.querySelector('input[data-testid="order-checkbox"], input.checkbox__control[id^="grid-table-bulk-checkbox"]');
        const cells = row.querySelectorAll(":scope > td");
        const totalCell = cells[totalIndex] || row.querySelector(".total-price")?.closest("td");
        const subtotalCell = cells[subtotalIndex] || null;
        const orderClass = [...row.classList].find((name) => name.startsWith("orderid_"));
        const rows = orderClass
          ? tableRows.filter((candidate) => (
            candidate.classList.contains(orderClass)
            && candidate.matches(".order-info, .item-info, .buyer-note-row")
            && !candidate.classList.contains("hidden")
          ))
          : [row];
        return {
          row,
          rows,
          columnCount,
          checkbox,
          buyer: buyerKey(row, checkbox),
          total: rowPrice(row, totalIndex, ".total-price"),
          subtotal: rowPrice(row, subtotalIndex, ".subtotal-price, .item-price"),
          totalCell,
          totalElement: totalCell?.querySelector(".total-price") || totalCell,
          postageElement: postageElement(subtotalCell),
          buyerElement: row.querySelector(".buyer-modal-trigger-wrapper button"),
          reasons: [],
        };
      })
      .filter((order) => order.checkbox || order.totalCell);
  }

  function classifyOrders(orders) {
    const buyers = new Map();
    orders.forEach((order) => {
      if (!order.buyer) return;
      const group = buyers.get(order.buyer) || [];
      group.push(order);
      buyers.set(order.buyer, group);
    });

    const repeatBuyers = new Set();
    if (settings.duplicateRule) {
      buyers.forEach((group, buyer) => {
        const total = group.reduce((sum, order) => sum + order.total, 0);
        if (group.length > 1 && total >= settings.duplicateThreshold) repeatBuyers.add(buyer);
      });
    }

    orders.forEach((order) => {
      if (settings.priceRule && order.total >= settings.priceThreshold) order.reasons.push("price");
      if (settings.deliveryRule && order.total - order.subtotal > settings.deliveryGap) order.reasons.push("delivery");
      if (repeatBuyers.has(order.buyer)) order.reasons.push("duplicate");
    });
  }

  function primaryReason(order) {
    if (order.reasons.includes("delivery")) return "delivery";
    if (order.reasons.includes("duplicate")) return "duplicate";
    return order.reasons[0] || "";
  }

  function formatAmount(value) {
    return `£${Number(value).toFixed(2)}`;
  }

  function formatCountText(template, count, amount) {
    return template
      .replaceAll("{order}", count === 1 ? "order" : "orders")
      .replaceAll("{amount}", formatAmount(amount));
  }

  function hexToRgba(hex, percentage) {
    const value = hex.slice(1);
    const red = Number.parseInt(value.slice(0, 2), 16);
    const green = Number.parseInt(value.slice(2, 4), 16);
    const blue = Number.parseInt(value.slice(4, 6), 16);
    return `rgba(${red}, ${green}, ${blue}, ${percentage / 100})`;
  }

  function clearOrder(order) {
    (order.rows || [order.row]).forEach((row) => {
      restoreTrailingSpan(row);
      row.classList.remove(...CLASS_NAMES);
      row.removeAttribute("data-eoh-reasons");
      row.removeAttribute("data-eoh-label");
      row.style.removeProperty("--eoh-colour");
      row.style.removeProperty("--eoh-wash");
      row.querySelectorAll(".eoh-field-mark").forEach((element) => {
        element.classList.remove(
          "eoh-field-mark",
          "eoh-field-wash",
          "eoh-field-edge",
          "eoh-field-outline",
          "eoh-field-price",
          "eoh-field-delivery",
          "eoh-field-duplicate",
        );
        element.style.removeProperty("--eoh-field-colour");
        element.style.removeProperty("--eoh-field-wash");
      });
    });
  }

  function markField(element, reason, colour) {
    if (!element) return;
    element.classList.add("eoh-field-mark", `eoh-field-${settings.highlightStyle}`, `eoh-field-${reason}`);
    element.style.setProperty("--eoh-field-colour", colour);
    element.style.setProperty("--eoh-field-wash", hexToRgba(colour, Math.min(50, settings.tintStrength + 14)));
  }

  function markOrders(orders) {
    const colours = {
      price: settings.priceColour,
      delivery: settings.deliveryColour,
      duplicate: settings.duplicateColour,
    };

    orders.forEach((order) => {
      clearOrder(order);
      const primary = primaryReason(order);
      if (!primary) return;
      const colour = colours[primary];
      order.rows.forEach((row) => {
        row.classList.add("eoh-marked", `eoh-${primary}`, `eoh-style-${settings.highlightStyle}`);
        row.dataset.eohReasons = order.reasons.join(" ");
        row.style.setProperty("--eoh-colour", colour);
        row.style.setProperty("--eoh-wash", hexToRgba(colour, settings.tintStrength));
        fillTrailingColumns(row, order.columnCount);
      });
      if (order.reasons.includes("price")) markField(order.totalElement, "price", colours.price);
      if (order.reasons.includes("delivery")) markField(order.postageElement, "delivery", colours.delivery);
      if (order.reasons.includes("duplicate")) markField(order.buyerElement, "duplicate", colours.duplicate);
    });
  }

  function getExpressCount() {
    const item = [...document.querySelectorAll("span.listbox__value")]
      .find((node) => node.textContent.trim().toLowerCase().startsWith("awaiting express delivery"));
    const match = item?.textContent.match(/\((\d+)\)/);
    return match ? Number(match[1]) : 0;
  }

  function summarise(orders) {
    const summary = { marked: 0, price: 0, delivery: 0, duplicate: 0 };
    orders.forEach((order) => {
      if (order.reasons.length) summary.marked += 1;
      order.reasons.forEach((reason) => { summary[reason] += 1; });
    });
    return summary;
  }

  function makeButton(label, className) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = className;
    button.textContent = label;
    return button;
  }

  function openSettingsPage() {
    const runtime = api?.runtime;
    if (!runtime) return;

    const fallback = () => {
      try {
        runtime.openOptionsPage?.();
      } catch (error) {
        console.error("Order Marks could not open Settings.", error);
      }
    };

    try {
      if (!runtime.sendMessage) {
        fallback();
        return;
      }
      const request = runtime.sendMessage({ type: "eoh:open-options" });
      if (request && typeof request.then === "function") {
        request.then((response) => {
          if (response && response.ok === false) fallback();
        }, fallback);
      }
    } catch (_error) {
      fallback();
    }
  }

  function buildToolbar() {
    const toolbar = document.createElement("section");
    toolbar.id = "eoh-toolbar";
    toolbar.className = "eoh-toolbar";
    toolbar.setAttribute("aria-label", "Order Marks");
    toolbar.innerHTML = `
      <div class="eoh-toolbar__head">
        <div class="eoh-toolbar__identity">
          <img class="eoh-toolbar__logo" src="${api.runtime.getURL("icons/icon32.png")}" alt="">
          <span><strong>Order Marks</strong><small id="eoh-page-label"></small></span>
        </div>
        <div class="eoh-toolbar__counts" aria-live="polite">
          <span class="eoh-count eoh-count--price"><i></i><b id="eoh-price-count">0</b><span id="eoh-price-label"></span></span>
          <span class="eoh-count eoh-count--delivery"><i></i><b id="eoh-delivery-count">0</b><span id="eoh-delivery-label"></span></span>
          <span class="eoh-count eoh-count--duplicate"><i></i><b id="eoh-duplicate-count">0</b><span id="eoh-duplicate-label"></span></span>
          <p class="eoh-express" id="eoh-express" hidden></p>
        </div>
        <div class="eoh-toolbar__controls"></div>
      </div>`;

    const controls = toolbar.querySelector(".eoh-toolbar__controls");
    const selectButton = makeButton("Select marked", "eoh-button eoh-button--primary");
    selectButton.id = "eoh-select-marked";
    const settingsButton = makeButton("Settings", "eoh-button");
    controls.append(selectButton, settingsButton);

    selectButton.addEventListener("click", selectMarkedOrders);
    settingsButton.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      openSettingsPage();
    });
    return toolbar;
  }

  function toolbarHost(table) {
    return document.querySelector("#mainGridContainer") || table.parentElement;
  }

  function renderToolbar(table, orders, status) {
    let toolbar = document.querySelector("#eoh-toolbar");
    if (!settings.showToolbar) {
      toolbar?.remove();
      return;
    }
    if (!toolbar) {
      toolbar = buildToolbar();
      toolbarHost(table)?.prepend(toolbar);
    }

    const summary = summarise(orders);
    toolbar.querySelector("#eoh-page-label").textContent = STATUS_LABELS[status] || "Seller Hub orders";
    toolbar.querySelector("#eoh-price-count").textContent = summary.price;
    toolbar.querySelector("#eoh-delivery-count").textContent = summary.delivery;
    toolbar.querySelector("#eoh-duplicate-count").textContent = summary.duplicate;
    toolbar.querySelector("#eoh-price-label").textContent = formatCountText(settings.priceCountText, summary.price, settings.priceThreshold);
    toolbar.querySelector("#eoh-delivery-label").textContent = formatCountText(settings.deliveryCountText, summary.delivery, settings.deliveryGap);
    toolbar.querySelector("#eoh-duplicate-label").textContent = formatCountText(settings.duplicateCountText, summary.duplicate, settings.duplicateThreshold);
    toolbar.style.setProperty("--eoh-price", settings.priceColour);
    toolbar.style.setProperty("--eoh-delivery", settings.deliveryColour);
    toolbar.style.setProperty("--eoh-duplicate", settings.duplicateColour);

    const express = toolbar.querySelector("#eoh-express");
    const expressCount = settings.showExpressReminder ? getExpressCount() : 0;
    express.hidden = expressCount === 0;
    express.textContent = expressCount === 1
      ? "1 order is awaiting express delivery."
      : `${expressCount} orders are awaiting express delivery.`;

    const selection = orders.filter(includeInSelection);
    const allSelected = selection.length > 0 && selection.every((order) => order.checkbox?.checked);
    const selectButton = toolbar.querySelector("#eoh-select-marked");
    selectButton.hidden = !settings.showSelectMarked;
    selectButton.textContent = summary.marked === 0
      ? "Select marked"
      : `${allSelected ? "Clear" : "Select"} ${summary.marked} marked`;
    selectButton.disabled = selection.length === 0;
  }

  function includeInSelection(order) {
    return Boolean(
      (settings.selectPrice && order.reasons.includes("price"))
      || (settings.selectDelivery && order.reasons.includes("delivery"))
      || (settings.selectDuplicates && order.reasons.includes("duplicate"))
    );
  }

  function selectMarkedOrders() {
    const table = findOrdersTable();
    if (!table) return;
    const orders = getOrders(table);
    classifyOrders(orders);
    const selection = orders.filter((order) => includeInSelection(order) && order.checkbox);
    const shouldSelect = !selection.length || !selection.every((order) => order.checkbox.checked);
    selection.forEach((order) => {
      if (order.checkbox.checked !== shouldSelect) order.checkbox.click();
    });
    renderToolbar(table, orders, getStatus());
  }

  function clearPage() {
    document.querySelector("#eoh-toolbar")?.remove();
    document.querySelectorAll("tr.eoh-marked").forEach((row) => {
      restoreTrailingSpan(row);
      row.classList.remove(...CLASS_NAMES);
      row.removeAttribute("data-eoh-reasons");
      row.removeAttribute("data-eoh-label");
      row.style.removeProperty("--eoh-colour");
      row.style.removeProperty("--eoh-wash");
      row.querySelectorAll(".eoh-field-mark").forEach((element) => {
        element.classList.remove(
          "eoh-field-mark",
          "eoh-field-wash",
          "eoh-field-edge",
          "eoh-field-outline",
          "eoh-field-price",
          "eoh-field-delivery",
          "eoh-field-duplicate",
        );
        element.style.removeProperty("--eoh-field-colour");
        element.style.removeProperty("--eoh-field-wash");
      });
    });
  }

  function applyPagePreferences() {
    document.documentElement.classList.toggle(
      "eoh-hide-promotional-banners",
      Boolean(settings.enabled && settings.hidePromotionalBanners),
    );
  }

  function run() {
    updateFrame = 0;
    applyPagePreferences();
    const status = getStatus();
    if (!pageIsEnabled(status)) {
      clearPage();
      return;
    }
    const table = findOrdersTable();
    if (!table) return;
    const orders = getOrders(table);
    classifyOrders(orders);
    markOrders(orders);
    renderToolbar(table, orders, status);
    window.dispatchEvent(new CustomEvent("eoh:updated", { detail: { status, ...summarise(orders) } }));
  }

  function scheduleRun() {
    if (updateFrame) cancelAnimationFrame(updateFrame);
    updateFrame = requestAnimationFrame(run);
  }

  function observePage() {
    tableObserver?.disconnect();
    tableObserver = new MutationObserver((mutations) => {
      const pageChanged = mutations.some((mutation) => [...mutation.addedNodes].some((node) => {
        if (!(node instanceof Element)) return false;
        if (node.closest("#eoh-toolbar")) return false;
        return node.matches("table, tbody, tr.order-info, tr.item-info, tr.buyer-note-row, #app-mod-orders-wrapper")
          || Boolean(node.querySelector("table, tr.order-info, tr.item-info, tr.buyer-note-row, #app-mod-orders-wrapper"));
      }));
      if (pageChanged) scheduleRun();
    });
    tableObserver.observe(document.body, { childList: true, subtree: true });
  }

  async function start() {
    settings = await EOHSettings.load();
    observePage();
    scheduleRun();

    api?.storage?.onChanged?.addListener(async (_changes, area) => {
      if (area !== "sync") return;
      settings = await EOHSettings.load();
      scheduleRun();
    });

    setInterval(() => {
      if (location.href === currentUrl) return;
      currentUrl = location.href;
      scheduleRun();
    }, 750);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start, { once: true });
  else start();
})();
