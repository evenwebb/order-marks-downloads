(function () {
  "use strict";

  const api = globalThis.browser?.runtime?.id ? globalThis.browser : globalThis.chrome;
  const CLASS_NAMES = ["eoh-marked", "eoh-price", "eoh-delivery", "eoh-special", "eoh-duplicate", "eoh-style-wash", "eoh-style-edge", "eoh-style-outline"];
  const PAGE_QUERY_KEYS = ["page", "pgn", "_pgn", "offset"];
  const MAX_EXTRA_PAGES = 20;
  const STATUS_LABELS = {
    ALL_ORDERS: "All orders",
    AWAITING_SHIPMENT: "Awaiting dispatch",
    AWAITING_SHIPMENT_OVERDUE: "Awaiting dispatch · Overdue",
    AWAITING_SHIPMENT_DUE_24H: "Awaiting dispatch · Due within 24 hours",
    AWAITING_EXPEDITED_SHIPMENT: "Awaiting dispatch · Express delivery",
    PAID_SHIPPED: "Paid and dispatched",
    AWAITING_PAYMENT: "Awaiting payment",
  };
  let settings = { ...EOHSettings.DEFAULTS };
  let currentUrl = location.href;
  let updateFrame = 0;
  let tableObserver;
  let extraPageCache = { key: "", orders: [] };
  let extraPageLoadKey = "";

  function getStatus() {
    const filter = new URL(location.href).searchParams.get("filter") || "";
    const fromUrl = filter.replace(/^status:/, "");
    if (fromUrl) return fromUrl;
    const selected = document.querySelector('select[name="fl-status"] option:checked');
    return selected ? selected.value : "";
  }

  function pageIsEnabled(status) {
    const key = EOHSettings.PAGE_KEYS[status];
    return Boolean(settings.enabled && key && settings[key]);
  }

  function parseMoney(text) {
    if (!text) return 0;
    const match = String(text).replace(/\u00a0/g, " ").match(/-?\s*(?:£|GBP)?\s*\d[\d.,]*/i);
    if (!match) return 0;
    let value = match[0].replace(/[^\d,.-]/g, "");
    const comma = value.lastIndexOf(",");
    const dot = value.lastIndexOf(".");

    if (comma !== -1 && dot !== -1) {
      if (comma > dot) value = value.replace(/\./g, "").replace(",", ".");
      else value = value.replace(/,/g, "");
    } else if (comma !== -1) {
      const decimals = value.length - comma - 1;
      value = decimals === 2 ? value.replace(",", ".") : value.replace(/,/g, "");
    }

    const number = Number.parseFloat(value);
    return Number.isFinite(number) ? number : 0;
  }

  function findOrdersTable(root = document) {
    const tables = [...root.querySelectorAll("table")];
    return tables.find((table) => table.querySelector("caption")?.textContent.trim() === "Orders")
      || root.querySelector("table.table-grid-component.new-grid")
      || tables.find((table) => table.querySelector('input[data-testid="order-checkbox"]'))
      || null;
  }

  function columnIndex(table, id, name) {
    const headers = [...table.querySelectorAll("thead tr:first-child > th")];
    const byId = headers.findIndex((header) => header.id === id);
    if (byId >= 0) return byId;
    return headers.findIndex((header) => header.textContent.trim().toLowerCase().startsWith(name));
  }

  function rowPrice(row, index, selector) {
    const cells = row.querySelectorAll(":scope > td");
    const cell = index >= 0 ? cells[index] : null;
    const source = cell?.querySelector(selector) || cell;
    return parseMoney(source?.textContent || "");
  }

  function buyerKey(row, checkbox) {
    if (checkbox?.dataset.buyerId) return checkbox.dataset.buyerId.trim().toLowerCase();
    const spans = row.querySelectorAll(".buyer-modal-trigger-wrapper button span");
    return spans.length ? spans[spans.length - 1].textContent.trim().toLowerCase() : "";
  }

  const SPECIAL_DELIVERY = /royal\s*mail\s*special(?:\s*delivery)?|special\s*delivery|\bspecialdelivery\b|\brm\s*special(?:\s*del(?:ivery)?)?\b/i;

  function visibleRows(rows) {
    return (rows || []).filter((row) => row && !row.classList.contains("buyer-note-row"));
  }

  function postageElement(root) {
    if (!root) return null;
    const item = [...root.querySelectorAll(".price-column-item")]
      .find((element) => /\bpostage\b/i.test(element.textContent));
    if (item) return item;
    const label = [...root.querySelectorAll("span")]
      .find((element) => /\bpostage\b/i.test(element.textContent));
    return label?.parentElement || null;
  }

  function postageCost(order) {
    const labelled = parseMoney(order.postageElement?.textContent || "");
    if (labelled > 0) return labelled;
    const gap = order.total - order.subtotal;
    return gap > 0 ? gap : 0;
  }

  function isItemTitle(element) {
    return Boolean(element.closest("a[href*='/itm/']"));
  }

  function compactSpecialNode(root) {
    return [...root.querySelectorAll("span, div, p, a, td, li, small, strong")]
      .filter((element) => {
        if (isItemTitle(element)) return false;
        const text = element.textContent.replace(/\s+/g, " ").trim();
        return text.length > 0 && text.length < 80 && SPECIAL_DELIVERY.test(text);
      })
      .sort((a, b) => a.textContent.trim().length - b.textContent.trim().length)[0] || null;
  }

  function shippingContextNode(root) {
    return [...root.querySelectorAll(".price-column-item, [class*='ship' i], [class*='deliver' i], [class*='post' i], [class*='logistic' i], [data-testid*='ship' i], [data-testid*='deliver' i]")]
      .find((element) => !isItemTitle(element) && SPECIAL_DELIVERY.test(element.textContent));
  }

  function specialDeliveryElement(rows) {
    for (const row of visibleRows(rows)) {
      const match = compactSpecialNode(row) || shippingContextNode(row);
      if (match) return match;
    }
    return null;
  }

  function hasSpecialDelivery(rows) {
    return Boolean(specialDeliveryElement(rows));
  }

  function spanCount(elements) {
    return elements.reduce((total, element) => {
      const span = Number.parseInt(element.getAttribute("colspan") || "1", 10);
      return total + (Number.isFinite(span) && span > 0 ? span : 1);
    }, 0);
  }

  function restoreTrailingSpan(row) {
    row.querySelectorAll(":scope > td[data-eoh-original-colspan]").forEach((cell) => {
      const original = cell.dataset.eohOriginalColspan;
      if (original) cell.setAttribute("colspan", original);
      else cell.removeAttribute("colspan");
      delete cell.dataset.eohOriginalColspan;
    });
  }

  function fillTrailingColumns(row, columnCount) {
    const cells = [...row.querySelectorAll(":scope > td")];
    const missing = columnCount - spanCount(cells);
    const lastCell = cells[cells.length - 1];
    if (!lastCell || missing <= 0) return;
    lastCell.dataset.eohOriginalColspan = lastCell.getAttribute("colspan") || "";
    lastCell.colSpan = (Number.parseInt(lastCell.getAttribute("colspan") || "1", 10) || 1) + missing;
  }

  function getOrders(table) {
    const totalIndex = columnIndex(table, "totalprice", "total");
    const subtotalIndex = columnIndex(table, "sold_for", "subtotal");
    const columnCount = spanCount([...table.querySelectorAll("thead tr:first-child > th")]);
    const tableRows = [...table.querySelectorAll("tbody > tr")];
    return [...table.querySelectorAll("tbody > tr.order-info")]
      .map((row) => {
        const checkbox = row.querySelector('input[data-testid="order-checkbox"], input.checkbox__control[id^="grid-table-bulk-checkbox"]');
        const cells = row.querySelectorAll(":scope > td");
        const totalCell = cells[totalIndex] || row.querySelector(".total-price")?.closest("td");
        const subtotalCell = cells[subtotalIndex] || null;
        const orderClass = [...row.classList].find((name) => name.startsWith("orderid_"));
        const rows = orderClass
          ? tableRows.filter((candidate) => (
            candidate.classList.contains(orderClass)
            && candidate.matches(".order-info, .item-info, .buyer-note-row")
            && !candidate.classList.contains("hidden")
          ))
          : [row];
        return {
          row,
          rows,
          columnCount,
          checkbox,
          orderId: orderClass ? orderClass.slice("orderid_".length) : "",
          buyer: buyerKey(row, checkbox),
          total: rowPrice(row, totalIndex, ".total-price"),
          subtotal: rowPrice(row, subtotalIndex, ".subtotal-price, .item-price"),
          totalCell,
          totalElement: totalCell?.querySelector(".total-price") || totalCell,
          postageElement: postageElement(subtotalCell) || postageElement(row),
          buyerElement: row.querySelector(".buyer-modal-trigger-wrapper button"),
          isSpecial: false,
          specialElement: null,
          reasons: [],
        };
      })
      .map((order) => {
        order.postageElement = order.postageElement
          || visibleRows(order.rows).map((row) => postageElement(row)).find(Boolean)
          || null;
        order.isSpecial = hasSpecialDelivery(order.rows);
        order.specialElement = specialDeliveryElement(order.rows) || order.postageElement;
        return order;
      })
      .filter((order) => order.checkbox || order.totalCell);
  }

  function listKey(url = location.href) {
    const parsed = new URL(url, location.href);
    PAGE_QUERY_KEYS.forEach((key) => parsed.searchParams.delete(key));
    parsed.hash = "";
    parsed.searchParams.sort();
    return `${parsed.pathname}?${parsed.searchParams.toString()}`;
  }

  function canonicalUrl(url) {
    const parsed = new URL(url, location.href);
    parsed.hash = "";
    parsed.searchParams.sort();
    return `${parsed.origin}${parsed.pathname}?${parsed.searchParams.toString()}`;
  }

  function pageIndex(url) {
    const parsed = new URL(url, location.href);
    if (parsed.searchParams.has("offset")) {
      const offset = Number(parsed.searchParams.get("offset") || 0);
      const limit = Number(parsed.searchParams.get("limit") || 0) || 25;
      return Math.floor(Math.max(0, offset) / limit) + 1;
    }
    for (const key of ["page", "pgn", "_pgn"]) {
      if (!parsed.searchParams.has(key)) continue;
      const value = Number(parsed.searchParams.get(key));
      return Number.isFinite(value) && value > 0 ? value : 1;
    }
    return 1;
  }

  function detectPageParam(urls) {
    const parsed = [new URL(location.href), ...urls.map((href) => new URL(href, location.href))];
    if (parsed.some((item) => item.searchParams.has("offset"))) return "offset";
    for (const key of ["page", "pgn", "_pgn"]) {
      if (parsed.some((item) => item.searchParams.has(key))) return key;
    }
    return "page";
  }

  function pageSize(root) {
    const urlLimit = Number(new URL(location.href).searchParams.get("limit") || 0);
    if (urlLimit > 0) return urlLimit;
    const select = root.querySelector('select[name="limit"], select[name="itemsPerPage"]');
    const selected = Number(select?.value || 0);
    if (selected > 0) return selected;
    const table = findOrdersTable(root);
    return (table ? getOrders(table).length : 0) || 25;
  }

  function withPage(url, page, paramName, limit) {
    const parsed = new URL(url, location.href);
    if (paramName === "offset") {
      const size = limit || Number(parsed.searchParams.get("limit") || 0) || 25;
      const offset = (page - 1) * size;
      if (offset <= 0) parsed.searchParams.delete("offset");
      else parsed.searchParams.set("offset", String(offset));
    } else if (page <= 1 && !new URL(location.href).searchParams.has(paramName)) {
      parsed.searchParams.delete(paramName);
    } else {
      parsed.searchParams.set(paramName, String(page));
    }
    return parsed.href;
  }

  function paginationAnchors(root, baseUrl) {
    const scope = root.querySelector("#app-mod-orders-wrapper")
      || root.querySelector("#mainGridContainer")
      || root;
    return [...scope.querySelectorAll("a[href]")].filter((anchor) => {
      let parsed;
      try {
        parsed = new URL(anchor.getAttribute("href") || anchor.href, baseUrl);
      } catch {
        return false;
      }
      if (parsed.origin !== new URL(baseUrl).origin || !/\/sh\/ord/.test(parsed.pathname)) return false;
      if (listKey(parsed.href) !== listKey(baseUrl)) return false;
      const label = `${anchor.getAttribute("aria-label") || ""} ${anchor.textContent}`;
      const numbered = /^\d+$/.test(anchor.textContent.trim());
      const paging = /page|next|prev|previous/i.test(label);
      const hasPageQuery = PAGE_QUERY_KEYS.some((key) => parsed.searchParams.has(key));
      return numbered || paging || hasPageQuery;
    });
  }

  function pageCountFromPagination(root, anchors) {
    const labeled = [...root.querySelectorAll("nav, .pagination, [class*='pagination'], [aria-label*='page' i]")]
      .map((element) => `${element.getAttribute("aria-label") || ""} ${element.textContent || ""}`)
      .join(" ");
    const ofMatch = labeled.match(/page\s+\d+\s+of\s+(\d+)/i) || labeled.match(/of\s+(\d+)\s+pages/i);
    if (ofMatch) return Number(ofMatch[1]);
    const numbers = anchors
      .map((anchor) => Number(anchor.textContent.trim()))
      .filter((value) => Number.isInteger(value) && value > 0);
    const nextControl = [...root.querySelectorAll("nav a, nav button, .pagination a, .pagination button, [class*='pagination'] a, [class*='pagination'] button")]
      .find((element) => /next/i.test(`${element.getAttribute("aria-label") || ""} ${element.textContent}`)
        && element.getAttribute("aria-disabled") !== "true"
        && !element.disabled);
    const max = Math.max(0, ...numbers);
    if (nextControl && max) return max + 1;
    if (nextControl) return 2;
    return max;
  }

  function listPageHrefs(root, baseUrl = location.href) {
    const anchors = paginationAnchors(root, baseUrl);
    const hrefs = [...new Set(anchors.map((anchor) => new URL(anchor.getAttribute("href") || anchor.href, baseUrl).href))];
    const total = pageCountFromPagination(root, anchors);
    const param = detectPageParam(hrefs);
    const limit = pageSize(root);
    const last = Math.min(Math.max(total, ...hrefs.map((href) => pageIndex(href)), 1), MAX_EXTRA_PAGES + 1);
    const pages = new Set();
    if (last > 1) {
      for (let page = 1; page <= last; page += 1) {
        pages.add(withPage(baseUrl, page, param, limit));
      }
    }
    hrefs.forEach((href) => pages.add(href));
    return [...pages];
  }

  function otherPageHrefs(root = document) {
    const current = pageIndex(location.href);
    return listPageHrefs(root, location.href).filter((href) => pageIndex(href) !== current);
  }

  function asOffPageOrder(order) {
    return {
      orderId: order.orderId,
      buyer: order.buyer,
      total: order.total,
      subtotal: order.subtotal,
      isSpecial: Boolean(order.isSpecial),
      row: null,
      rows: [],
      checkbox: null,
      reasons: [],
    };
  }

  function orderSignature(orders) {
    return orders.map((order) => order.orderId).filter(Boolean).sort().join(",");
  }

  async function fetchPageOrders(url) {
    const response = await fetch(url, { credentials: "include", cache: "no-store" });
    if (!response.ok) return { orders: [], hrefs: [] };
    const html = await response.text();
    if (/signin\.ebay/i.test(html.slice(0, 4000))) return { orders: [], hrefs: [] };
    const doc = new DOMParser().parseFromString(html, "text/html");
    const table = findOrdersTable(doc);
    return {
      orders: table ? getOrders(table).map(asOffPageOrder) : [],
      hrefs: listPageHrefs(doc, url),
    };
  }

  async function loadExtraPageOrders(visible, key) {
    const seed = otherPageHrefs(document);
    if (!seed.length) return [];
    const seenIds = new Set(visible.map((order) => order.orderId).filter(Boolean));
    const visibleSig = orderSignature(visible);
    const seenUrls = new Set([canonicalUrl(location.href)]);
    const queue = [...seed];
    const extras = [];
    while (queue.length && seenUrls.size - 1 < MAX_EXTRA_PAGES) {
      const url = queue.shift();
      const canon = canonicalUrl(url);
      if (seenUrls.has(canon)) continue;
      seenUrls.add(canon);
      try {
        const { orders, hrefs } = await fetchPageOrders(url);
        if (orderSignature(orders) === visibleSig) continue;
        orders.forEach((order) => {
          if (order.orderId && seenIds.has(order.orderId)) return;
          extras.push(order);
          if (order.orderId) seenIds.add(order.orderId);
        });
        hrefs.forEach((href) => {
          if (!seenUrls.has(canonicalUrl(href))) queue.push(href);
        });
      } catch (_error) {
        // Keep current-page results if a later page cannot be read.
      }
    }
    return extras;
  }

  function requestExtraPages(visible, key) {
    if (extraPageLoadKey === key) return;
    extraPageLoadKey = key;
    loadExtraPageOrders(visible, key).then((orders) => {
      if (listKey() !== key) return;
      extraPageCache = { key, orders };
      extraPageLoadKey = extraPageLoadKey === key ? "" : extraPageLoadKey;
      scheduleRun();
    }, () => {
      if (extraPageLoadKey === key) extraPageLoadKey = "";
    });
  }

  function extraOrdersFor(visible) {
    const key = listKey();
    if (extraPageCache.key === key) return extraPageCache.orders;
    if (otherPageHrefs(document).length) requestExtraPages(visible, key);
    else extraPageCache = { key, orders: [] };
    return extraPageCache.key === key ? extraPageCache.orders : [];
  }

  function combinedOrders(visible) {
    const extras = extraOrdersFor(visible);
    const seen = new Set(visible.map((order) => order.orderId).filter(Boolean));
    const merged = visible.concat(extras.filter((order) => !order.orderId || !seen.has(order.orderId)));
    merged.forEach((order) => { order.reasons = []; });
    return merged;
  }


  function classifyOrders(orders) {
    const buyers = new Map();
    orders.forEach((order) => {
      if (!order.buyer) return;
      const group = buyers.get(order.buyer) || [];
      group.push(order);
      buyers.set(order.buyer, group);
    });

    const repeatBuyers = new Set();
    const trackingBuyers = new Set();
    buyers.forEach((group, buyer) => {
      if (group.length < 2) return;
      const total = group.reduce((sum, order) => sum + order.total, 0);
      if (settings.duplicateRule) repeatBuyers.add(buyer);
      if (settings.duplicateRule && settings.priceRule && total >= settings.priceThreshold) {
        trackingBuyers.add(buyer);
      }
    });

    orders.forEach((order) => {
      if (settings.priceRule && (order.total >= settings.priceThreshold || trackingBuyers.has(order.buyer))) {
        order.reasons.push("price");
      }
      if (settings.deliveryRule && postageCost(order) > settings.deliveryGap) order.reasons.push("delivery");
      if (settings.specialRule && order.isSpecial) order.reasons.push("special");
      if (repeatBuyers.has(order.buyer)) order.reasons.push("duplicate");
    });
  }

  function primaryReason(order) {
    if (order.reasons.includes("special")) return "special";
    if (order.reasons.includes("delivery")) return "delivery";
    if (order.reasons.includes("duplicate")) return "duplicate";
    return order.reasons[0] || "";
  }

  function formatAmount(value) {
    return `£${Number(value).toFixed(2)}`;
  }

  function formatCountText(template, count, amount) {
    const one = count === 1;
    return String(template || "")
      .replace(/\{([^\{\}|]+)\|([^\{\}|]+)\}/g, (_, singular, plural) => (one ? singular : plural).trim())
      .replaceAll("{order}", one ? "order" : "orders")
      .replaceAll("{amount}", formatAmount(amount));
  }

  function hexToRgba(hex, percentage) {
    const value = hex.slice(1);
    const red = Number.parseInt(value.slice(0, 2), 16);
    const green = Number.parseInt(value.slice(2, 4), 16);
    const blue = Number.parseInt(value.slice(4, 6), 16);
    return `rgba(${red}, ${green}, ${blue}, ${percentage / 100})`;
  }

  function clearOrder(order) {
    (order.rows || [order.row]).forEach((row) => {
      restoreTrailingSpan(row);
      row.classList.remove(...CLASS_NAMES);
      row.removeAttribute("data-eoh-reasons");
      row.removeAttribute("data-eoh-label");
      row.style.removeProperty("--eoh-colour");
      row.style.removeProperty("--eoh-wash");
      row.querySelectorAll(".eoh-field-mark").forEach((element) => {
        element.classList.remove(
          "eoh-field-mark",
          "eoh-field-wash",
          "eoh-field-edge",
          "eoh-field-outline",
          "eoh-field-price",
          "eoh-field-delivery",
          "eoh-field-special",
          "eoh-field-duplicate",
        );
        element.style.removeProperty("--eoh-field-colour");
        element.style.removeProperty("--eoh-field-wash");
      });
    });
  }

  function markField(element, reason, colour) {
    if (!element) return;
    element.classList.add("eoh-field-mark", `eoh-field-${settings.highlightStyle}`, `eoh-field-${reason}`);
    element.style.setProperty("--eoh-field-colour", colour);
    element.style.setProperty("--eoh-field-wash", hexToRgba(colour, Math.min(50, settings.tintStrength + 14)));
  }

  function markOrders(orders) {
    const colours = {
      price: settings.priceColour,
      delivery: settings.deliveryColour,
      special: settings.specialColour,
      duplicate: settings.duplicateColour,
    };

    orders.forEach((order) => {
      clearOrder(order);
      const primary = primaryReason(order);
      if (!primary) return;
      const colour = colours[primary];
      visibleRows(order.rows).forEach((row) => {
        row.classList.add("eoh-marked", `eoh-${primary}`, `eoh-style-${settings.highlightStyle}`);
        row.dataset.eohReasons = order.reasons.join(" ");
        row.style.setProperty("--eoh-colour", colour);
        row.style.setProperty("--eoh-wash", hexToRgba(colour, settings.tintStrength));
        fillTrailingColumns(row, order.columnCount);
      });
      if (order.reasons.includes("price")) markField(order.totalElement, "price", colours.price);
      const specialField = order.specialElement || order.postageElement;
      if (order.reasons.includes("delivery") && order.postageElement && order.postageElement !== specialField) {
        markField(order.postageElement, "delivery", colours.delivery);
      }
      if (order.reasons.includes("special")) markField(specialField, "special", colours.special);
      if (order.reasons.includes("duplicate")) markField(order.buyerElement, "duplicate", colours.duplicate);
    });
  }

  function getExpressCount() {
    const item = [...document.querySelectorAll("span.listbox__value")]
      .find((node) => node.textContent.trim().toLowerCase().startsWith("awaiting express delivery"));
    const match = item?.textContent.match(/\((\d+)\)/);
    return match ? Number(match[1]) : 0;
  }

  function summarise(orders) {
    const summary = { marked: 0, price: 0, delivery: 0, special: 0, duplicate: 0 };
    orders.forEach((order) => {
      if (order.reasons.length) summary.marked += 1;
      order.reasons.forEach((reason) => { summary[reason] += 1; });
    });
    return summary;
  }

  function makeButton(label, className) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = className;
    button.textContent = label;
    return button;
  }

  function openSettingsPage() {
    const runtime = api?.runtime;
    if (!runtime) return;

    const fallback = () => {
      try {
        runtime.openOptionsPage?.();
      } catch (error) {
        console.error("Order Marks could not open Settings.", error);
      }
    };

    try {
      if (!runtime.sendMessage) {
        fallback();
        return;
      }
      const request = runtime.sendMessage({ type: "eoh:open-options" });
      if (request && typeof request.then === "function") {
        request.then((response) => {
          if (response && response.ok === false) fallback();
        }, fallback);
      }
    } catch (_error) {
      fallback();
    }
  }

  function buildToolbar() {
    const toolbar = document.createElement("section");
    toolbar.id = "eoh-toolbar";
    toolbar.className = "eoh-toolbar";
    toolbar.setAttribute("aria-label", "Order Marks");
    toolbar.innerHTML = `
      <div class="eoh-toolbar__head">
        <div class="eoh-toolbar__identity">
          <img class="eoh-toolbar__logo" src="${api.runtime.getURL("icons/icon32.png")}" alt="">
          <span><strong>Order Marks</strong><small id="eoh-page-label"></small></span>
        </div>
        <div class="eoh-toolbar__counts" aria-live="polite">
          <span class="eoh-count eoh-count--price"><i></i><b id="eoh-price-count">0</b><span id="eoh-price-label"></span></span>
          <span class="eoh-count eoh-count--delivery"><i></i><b id="eoh-delivery-count">0</b><span id="eoh-delivery-label"></span></span>
          <span class="eoh-count eoh-count--special"><i></i><b id="eoh-special-count">0</b><span id="eoh-special-label"></span></span>
          <span class="eoh-count eoh-count--duplicate"><i></i><b id="eoh-duplicate-count">0</b><span id="eoh-duplicate-label"></span></span>
          <p class="eoh-express" id="eoh-express" hidden></p>
        </div>
        <div class="eoh-toolbar__controls"></div>
      </div>`;

    const controls = toolbar.querySelector(".eoh-toolbar__controls");
    const selectButton = makeButton("Select marked", "eoh-button eoh-button--primary");
    selectButton.id = "eoh-select-marked";
    const settingsButton = makeButton("Settings", "eoh-button");
    controls.append(selectButton, settingsButton);

    selectButton.addEventListener("click", selectMarkedOrders);
    settingsButton.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      openSettingsPage();
    });
    return toolbar;
  }


  function offPageMarked(orders) {
    return orders.filter((order) => !order.row && order.reasons.length);
  }

  function buildOffPageNotice() {
    const notice = document.createElement("section");
    notice.id = "eoh-offpage";
    notice.className = "eoh-toolbar eoh-toolbar--offpage";
    notice.setAttribute("aria-label", "Order Marks on other pages");
    notice.innerHTML = `
      <div class="eoh-toolbar__head">
        <div class="eoh-toolbar__identity">
          <img class="eoh-toolbar__logo" src="${api.runtime.getURL("icons/icon32.png")}" alt="">
          <span><strong>Order Marks</strong><small>Highlighted orders on another page</small></span>
        </div>
        <div class="eoh-toolbar__counts" aria-live="polite">
          <p class="eoh-offpage-message" id="eoh-offpage-message"></p>
          <span class="eoh-count eoh-count--price" id="eoh-offpage-price"><i></i><b id="eoh-offpage-price-count">0</b><span id="eoh-offpage-price-label"></span></span>
          <span class="eoh-count eoh-count--delivery" id="eoh-offpage-delivery"><i></i><b id="eoh-offpage-delivery-count">0</b><span id="eoh-offpage-delivery-label"></span></span>
          <span class="eoh-count eoh-count--special" id="eoh-offpage-special"><i></i><b id="eoh-offpage-special-count">0</b><span id="eoh-offpage-special-label"></span></span>
          <span class="eoh-count eoh-count--duplicate" id="eoh-offpage-duplicate"><i></i><b id="eoh-offpage-duplicate-count">0</b><span id="eoh-offpage-duplicate-label"></span></span>
        </div>
      </div>`;
    return notice;
  }

  function renderOffPageNotice(table, orders) {
    const marked = offPageMarked(orders);
    let notice = document.querySelector("#eoh-offpage");
    if (!marked.length) {
      notice?.remove();
      return;
    }
    if (!notice) {
      notice = buildOffPageNotice();
      toolbarHost(table)?.append(notice);
    }
    const summary = summarise(marked);
    notice.querySelector("#eoh-offpage-message").textContent = summary.marked === 1
      ? "There is 1 highlighted order on another page."
      : `There are ${summary.marked} highlighted orders on other pages.`;
    notice.querySelector("#eoh-offpage-price-count").textContent = summary.price;
    notice.querySelector("#eoh-offpage-delivery-count").textContent = summary.delivery;
    notice.querySelector("#eoh-offpage-special-count").textContent = summary.special;
    notice.querySelector("#eoh-offpage-duplicate-count").textContent = summary.duplicate;
    notice.querySelector("#eoh-offpage-price-label").textContent = formatCountText(settings.priceCountText, summary.price, settings.priceThreshold);
    notice.querySelector("#eoh-offpage-delivery-label").textContent = formatCountText(settings.deliveryCountText, summary.delivery, settings.deliveryGap);
    notice.querySelector("#eoh-offpage-special-label").textContent = formatCountText(settings.specialCountText, summary.special, 0);
    notice.querySelector("#eoh-offpage-duplicate-label").textContent = formatCountText(settings.duplicateCountText, summary.duplicate, settings.duplicateThreshold);
    notice.querySelector("#eoh-offpage-price").hidden = summary.price === 0;
    notice.querySelector("#eoh-offpage-delivery").hidden = summary.delivery === 0;
    notice.querySelector("#eoh-offpage-special").hidden = summary.special === 0;
    notice.querySelector("#eoh-offpage-duplicate").hidden = summary.duplicate === 0;
    notice.style.setProperty("--eoh-price", settings.priceColour);
    notice.style.setProperty("--eoh-delivery", settings.deliveryColour);
    notice.style.setProperty("--eoh-special", settings.specialColour);
    notice.style.setProperty("--eoh-duplicate", settings.duplicateColour);
  }

  function toolbarHost(table) {
    return document.querySelector("#mainGridContainer") || table.parentElement;
  }

  function renderToolbar(table, orders, status) {
    let toolbar = document.querySelector("#eoh-toolbar");
    if (!settings.showToolbar) {
      toolbar?.remove();
      renderOffPageNotice(table, orders);
      return;
    }
    if (!toolbar) {
      toolbar = buildToolbar();
      toolbarHost(table)?.prepend(toolbar);
    }

    const summary = summarise(orders);
    toolbar.querySelector("#eoh-page-label").textContent = STATUS_LABELS[status] || "Seller Hub orders";
    toolbar.querySelector("#eoh-price-count").textContent = summary.price;
    toolbar.querySelector("#eoh-delivery-count").textContent = summary.delivery;
    toolbar.querySelector("#eoh-special-count").textContent = summary.special;
    toolbar.querySelector("#eoh-duplicate-count").textContent = summary.duplicate;
    toolbar.querySelector("#eoh-price-label").textContent = formatCountText(settings.priceCountText, summary.price, settings.priceThreshold);
    toolbar.querySelector("#eoh-delivery-label").textContent = formatCountText(settings.deliveryCountText, summary.delivery, settings.deliveryGap);
    toolbar.querySelector("#eoh-special-label").textContent = formatCountText(settings.specialCountText, summary.special, 0);
    toolbar.querySelector("#eoh-duplicate-label").textContent = formatCountText(settings.duplicateCountText, summary.duplicate, settings.duplicateThreshold);
    const hideCount = (enabled, count) => !enabled || (settings.hideZeroCounts !== false && count === 0);
    toolbar.querySelector("#eoh-price-count").closest(".eoh-count").hidden = hideCount(settings.priceRule, summary.price);
    toolbar.querySelector("#eoh-delivery-count").closest(".eoh-count").hidden = hideCount(settings.deliveryRule, summary.delivery);
    toolbar.querySelector("#eoh-special-count").closest(".eoh-count").hidden = hideCount(settings.specialRule, summary.special);
    toolbar.querySelector("#eoh-duplicate-count").closest(".eoh-count").hidden = hideCount(settings.duplicateRule, summary.duplicate);
    toolbar.style.setProperty("--eoh-price", settings.priceColour);
    toolbar.style.setProperty("--eoh-delivery", settings.deliveryColour);
    toolbar.style.setProperty("--eoh-special", settings.specialColour);
    toolbar.style.setProperty("--eoh-duplicate", settings.duplicateColour);

    const express = toolbar.querySelector("#eoh-express");
    const expressCount = settings.showExpressReminder && !settings.specialRule ? getExpressCount() : 0;
    express.hidden = expressCount === 0;
    express.textContent = expressCount === 1
      ? "1 order is awaiting express delivery."
      : `${expressCount} orders are awaiting express delivery.`;

    const selection = orders.filter((order) => includeInSelection(order) && order.checkbox);
    const allSelected = selection.length > 0 && selection.every((order) => order.checkbox.checked);
    const selectButton = toolbar.querySelector("#eoh-select-marked");
    const selectionLabel = settings.invertSelection ? "unmarked" : "marked";
    selectButton.hidden = !settings.showSelectMarked;
    selectButton.textContent = selection.length === 0
      ? `Select ${selectionLabel}`
      : `${allSelected ? "Clear" : "Select"} ${selection.length} ${selectionLabel}`;
    selectButton.disabled = selection.length === 0;
    renderOffPageNotice(table, orders);
  }

  function includeInSelection(order) {
    if (settings.invertSelection) return order.reasons.length === 0;
    return Boolean(
      (settings.selectPrice && order.reasons.includes("price"))
      || (settings.selectDelivery && order.reasons.includes("delivery"))
      || (settings.selectSpecial && order.reasons.includes("special"))
      || (settings.selectDuplicates && order.reasons.includes("duplicate"))
    );
  }

  function selectMarkedOrders() {
    const table = findOrdersTable();
    if (!table) return;
    const orders = combinedOrders(getOrders(table));
    classifyOrders(orders);
    const selection = orders.filter((order) => includeInSelection(order) && order.checkbox);
    const shouldSelect = !selection.length || !selection.every((order) => order.checkbox.checked);
    selection.forEach((order) => {
      if (order.checkbox.checked !== shouldSelect) order.checkbox.click();
    });
    renderToolbar(table, orders, getStatus());
    renderOffPageNotice(table, orders);
  }

  function clearPage() {
    document.querySelector("#eoh-toolbar")?.remove();
    document.querySelector("#eoh-offpage")?.remove();
    document.querySelectorAll("tr.eoh-marked").forEach((row) => {
      restoreTrailingSpan(row);
      row.classList.remove(...CLASS_NAMES);
      row.removeAttribute("data-eoh-reasons");
      row.removeAttribute("data-eoh-label");
      row.style.removeProperty("--eoh-colour");
      row.style.removeProperty("--eoh-wash");
      row.querySelectorAll(".eoh-field-mark").forEach((element) => {
        element.classList.remove(
          "eoh-field-mark",
          "eoh-field-wash",
          "eoh-field-edge",
          "eoh-field-outline",
          "eoh-field-price",
          "eoh-field-delivery",
          "eoh-field-special",
          "eoh-field-duplicate",
        );
        element.style.removeProperty("--eoh-field-colour");
        element.style.removeProperty("--eoh-field-wash");
      });
    });
  }

  function applyPagePreferences() {
    document.documentElement.classList.toggle(
      "eoh-hide-promotional-banners",
      Boolean(settings.enabled && settings.hidePromotionalBanners),
    );
  }

  function run() {
    updateFrame = 0;
    applyPagePreferences();
    const status = getStatus();
    if (!pageIsEnabled(status)) {
      clearPage();
      extraPageCache = { key: "", orders: [] };
      extraPageLoadKey = "";
      return;
    }
    const table = findOrdersTable();
    if (!table) return;
    const visible = getOrders(table);
    const orders = combinedOrders(visible);
    classifyOrders(orders);
    markOrders(visible);
    renderToolbar(table, orders, status);
    renderOffPageNotice(table, orders);
    window.dispatchEvent(new CustomEvent("eoh:updated", { detail: { status, ...summarise(orders) } }));
  }

  function scheduleRun() {
    if (updateFrame) cancelAnimationFrame(updateFrame);
    updateFrame = requestAnimationFrame(run);
  }

  function observePage() {
    tableObserver?.disconnect();
    tableObserver = new MutationObserver((mutations) => {
      const pageChanged = mutations.some((mutation) => [...mutation.addedNodes].some((node) => {
        if (!(node instanceof Element)) return false;
        if (node.closest("#eoh-toolbar, #eoh-offpage")) return false;
        return node.matches("table, tbody, tr.order-info, tr.item-info, tr.buyer-note-row, #app-mod-orders-wrapper")
          || Boolean(node.querySelector("table, tr.order-info, tr.item-info, tr.buyer-note-row, #app-mod-orders-wrapper"));
      }));
      if (pageChanged) scheduleRun();
    });
    tableObserver.observe(document.body, { childList: true, subtree: true });
  }

  async function start() {
    settings = await EOHSettings.load();
    observePage();
    scheduleRun();

    api?.storage?.onChanged?.addListener(async (_changes, area) => {
      if (area !== "sync") return;
      settings = await EOHSettings.load();
      scheduleRun();
    });

    setInterval(() => {
      if (location.href === currentUrl) return;
      currentUrl = location.href;
      scheduleRun();
    }, 750);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start, { once: true });
  else start();
})();
