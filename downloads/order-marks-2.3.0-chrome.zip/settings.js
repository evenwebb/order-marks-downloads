(function (root) {
  "use strict";

  const DEFAULTS = Object.freeze({
    enabled: true,
    priceRule: true,
    priceThreshold: 9.9,
    deliveryRule: true,
    deliveryGap: 7,
    specialRule: true,
    duplicateRule: true,
    duplicateThreshold: 9.9,
    enableAllOrders: true,
    enableAwaitingShipment: true,
    enablePaidShipped: true,
    enableAwaitingPayment: false,
    hidePromotionalBanners: true,
    showToolbar: true,
    showSelectMarked: true,
    showExpressReminder: true,
    hideZeroCounts: true,
    priceCountText: "{order} {needs|need} tracking",
    deliveryCountText: "{order} with paid delivery",
    specialCountText: "{order} with Special Delivery",
    duplicateCountText: "{order} to merge",
    selectPrice: true,
    selectDelivery: true,
    selectSpecial: true,
    selectDuplicates: true,
    invertSelection: false,
    highlightStyle: "wash",
    priceColour: "#c84949",
    deliveryColour: "#b45c38",
    specialColour: "#7a5bb7",
    duplicateColour: "#26785a",
    tintStrength: 14,
  });

  const PAGE_KEYS = Object.freeze({
    ALL_ORDERS: "enableAllOrders",
    AWAITING_SHIPMENT: "enableAwaitingShipment",
    AWAITING_SHIPMENT_OVERDUE: "enableAwaitingShipment",
    AWAITING_SHIPMENT_DUE_24H: "enableAwaitingShipment",
    AWAITING_EXPEDITED_SHIPMENT: "enableAwaitingShipment",
    PAID_SHIPPED: "enablePaidShipped",
    AWAITING_PAYMENT: "enableAwaitingPayment",
  });

  function storageArea() {
    const api = globalThis.browser?.runtime?.id ? globalThis.browser : globalThis.chrome;
    return api && api.storage && api.storage.sync;
  }

  function normalise(input) {
    const source = input || {};
    const result = { ...DEFAULTS, ...source };
    const positiveNumbers = ["priceThreshold", "deliveryGap", "duplicateThreshold"];

    positiveNumbers.forEach((key) => {
      const value = Number(result[key]);
      result[key] = Number.isFinite(value) && value >= 0 ? value : DEFAULTS[key];
    });

    const strength = Number(result.tintStrength);
    result.tintStrength = Number.isFinite(strength)
      ? Math.min(30, Math.max(6, Math.round(strength)))
      : DEFAULTS.tintStrength;

    if (!["wash", "edge", "outline"].includes(result.highlightStyle)) {
      result.highlightStyle = DEFAULTS.highlightStyle;
    }

    ["priceColour", "deliveryColour", "specialColour", "duplicateColour"].forEach((key) => {
      if (!/^#[0-9a-f]{6}$/i.test(result[key])) result[key] = DEFAULTS[key];
    });

    ["priceCountText", "deliveryCountText", "specialCountText", "duplicateCountText"].forEach((key) => {
      if (typeof result[key] !== "string") result[key] = DEFAULTS[key];
      result[key] = result[key].replace(/\s+/g, " ").trim().slice(0, 100);
    });

    return result;
  }

  const LEGACY_COUNT_TEXT = Object.freeze({
    deliveryCountText: "{order} with Special Delivery",
    priceCountText: "{order} need tracking",
  });

  async function load() {
    const storage = storageArea();
    if (!storage) return { ...DEFAULTS };
    const stored = await storage.get(DEFAULTS);
    const migrated = {};
    Object.entries(LEGACY_COUNT_TEXT).forEach(([key, previous]) => {
      if (stored[key] === previous) migrated[key] = DEFAULTS[key];
    });
    if (stored.deliveryColour === "#7a5bb7" && stored.specialColour === "#b45c38") {
      migrated.deliveryColour = DEFAULTS.deliveryColour;
      migrated.specialColour = DEFAULTS.specialColour;
    }
    const settings = normalise({ ...stored, ...migrated });
    if (Object.keys(migrated).length) await storage.set(migrated);
    return settings;
  }

  async function save(values) {
    const storage = storageArea();
    const settings = normalise(values);
    if (storage) await storage.set(settings);
    return settings;
  }

  async function reset() {
    const storage = storageArea();
    if (storage) await storage.set(DEFAULTS);
    return { ...DEFAULTS };
  }

  root.EOHSettings = { DEFAULTS, PAGE_KEYS, load, normalise, reset, save };
})(globalThis);

